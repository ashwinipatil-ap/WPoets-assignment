1. How long did you spend on the coding test? What would you add to your solution if you had more time? If you didn't spend much time on the coding test then use this as an opportunity to explain what you would add.
Answer : I have spent 12 hrs on the coding. If i had more time i would have made interface changes more interactive what it is right now. I would have added javascript validations on crud operations.

2. How would you track down a performance issue in production? Have you ever had to do this?
Answer : We had applied profiler for our current project in our company. We had some performances issues we fixed them by storing static data in redis.

Yes I have came across this issue, I have tried to solve this issue by using below,
 - Applying Profiler to check which queries are taking time.
 - Applying Indexing for table columns which are frequently used in where clause.
 - Used minified js and css files.
 - Used Redis to store frequently used data.(i.e accessing first time data from database and after from Redis)

3. Please describe yourself using JSON.
Answer : [{"Personal Details":{"Name":"Ashwini Patil","Email":"86ashwinipatil@gmail.com","Contact No":"8970411743","Address":"H.No:38 Patil Galli Gunjenhatti, Belagavi-591143."},"Academic Details":{"BE":{"College Name":"Gogte Institute of Technology,Belgaum","Score":"71%"},"Diploma":{"College Name":"Maratha Mandal Polytechnic,Belgaum","Score":"76%"},"10th":{"School Name":"Shri shivaji High School,Kadoli,Belgaum","Score":"87%"}},"Skill sets":{"Coding Languages":"HTML, CSS, PHP, Bootstrap, JQuery, JavaScript","Data Management":"MySQL, phpMyAdmin","Coding Framework":"CodeIgniter"},"Professional Experience":{"Year":1.5,"Designation":"Jr. Software Developer"}}]