
<!DOCTYPE html>
<html>
<head>
	<meta http-equiv="content-type" content="width=device-width, initial-scale=1, text/html; charset=utf-8 " />
	<title>WPeot Assignment</title>

	<link href="https://cdnjs.cloudflare.com/ajax/libs/jqueryui/1.12.1/jquery-ui.min.css" rel="stylesheet">
	<link href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.3.1/css/bootstrap.min.css" rel="stylesheet">
	<link href="https://cdnjs.cloudflare.com/ajax/libs/AlertifyJS/1.11.2/css/alertify.min.css" rel="stylesheet">
	<link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
	
</head>
<body>
	<?php session_start(); 
	define('icon_access_path','http://localhost/assignment/CRUD/tab_icon/');
	define('slider_access_path','http://localhost/assignment/CRUD/slider_images/');
	?>