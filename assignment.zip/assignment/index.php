<?php 
    include "header.php";
    include "access_data.php";
    $data = get_data();
?>

<div class="container" id="web">
  <div class="text-center mb-4 mt-5 m-mb-0">
    <p class="text-white fs-12 mb-3 m-fs-9">DelphianLogic in Action</p>
    <p class="text-white fs m-fs-7 mb-0">Welcome to the World of DelphianLogic. Start Learning...</p>
  </div>
  <br>
  <!-- Nav tabs -->
  <div class="row media-hide">
  <div class="col-sm-3" style="background-color: #fff; padding-top: 15px;">
    <div class="nav flex-column nav-pills" id="v-pills-tab" role="tablist" aria-orientation="vertical">
      <?php foreach ($data as $key => $value) {
        $id = 'v-pills-'.$value['tab_name'];
        $href = '#v-pills-'.$value['tab_name'];
        $labelledby = 'v-pills-'.$value['tab_name'].'-tab';
        if($key == 0){ ?>
          <a class="nav-link active tab-names" data-tabname="<?php echo $value['tab_name']; ?>" id="<?php echo $labelledby; ?>" data-toggle="pill" href="<?php echo $href; ?>" role="tab" aria-controls="<?php echo $id; ?>" aria-selected="true"><span> <img src="<?php echo icon_access_path.$value['tab_icon']; ?>" style="width:10%"></span>&nbsp;&nbsp;&nbsp; <?php echo $value['tab_name']; ?></a>
        <?php }else{ ?>



          <!-- <div class="">
            <div id="demo" class="carousel slide" data-ride="carousel">
                <ul class="carousel-indicators">
                  <?php 
                    $slider_content = json_decode($value['slider_content'],1);
                    foreach ($slider_content as $k => $val) {
                      if($k == 0){ ?>
                        <li data-target="#demo" data-tabname="<?php echo $value['tab_name']; ?>" data-slide-to="<?php echo $k; ?>" class="active select-slider column2-indicator"></li>
                      <?php }else{ ?>
                        <li data-target="#demo" data-tabname="<?php echo $value['tab_name']; ?>" data-slide-to="<?php echo $k; ?>" class="select-slider column2-indicator"></li>
                      <?php } } ?>
                </ul>
                <div class="carousel-inner slider_1"> <?php 
                    $slider_content = json_decode($value['slider_content'],1);
                    foreach ($slider_content as $k => $val) {
                      if($k == 0){ ?>
                        <div class="carousel-item active">
                          <img src="https://via.placeholder.com/468x312/6abbd8/808080?text=+" alt="Chicago" style="width:100%">
                          <div class="carousel-caption">
                            <p><?php echo $val; ?></p>
                          </div>   
                        </div>
                      <?php }else{ ?>
                       <div class="carousel-item">
                          <img src="https://via.placeholder.com/468x312/6abbd8/808080?text=+" alt="Chicago" style="width:100%">
                          <div class="carousel-caption">
                            <p><?php echo $val; ?></p>
                          </div>   
                        </div>
                  <?php } } ?>
                </div>
              </div>
          </div> -->



          <a class="nav-link tab-names" data-tabname="<?php echo $value['tab_name']; ?>" id="<?php echo $labelledby; ?>" data-toggle="pill" href="<?php echo $href; ?>" role="tab" aria-controls="<?php echo $id; ?>" aria-selected="true"><span> <img src="<?php echo icon_access_path.$value['tab_icon']; ?>" style="width:10%"></span>&nbsp;&nbsp;&nbsp; <?php echo $value['tab_name']; ?></a>
       <?php } } ?>
    </div>
  </div>
  <div class="col-sm-9">
            <?php 
            $count = count($data);
            foreach ($data as $key => $value) { 
              $id = 'v-pills-'.$value['tab_name'];
              $labelledby = 'v-pills-'.$value['tab_name'].'-tab'; ?>
              <?php if($key == 0){ ?>
                <div class="row">
                <div class="col-sm-6 back">
                  <div class="tab-content" id="v-pills-tabContent">
                <div class="tab-pane fade show active" id="<?php echo $id; ?>" role="tabpanel" aria-labelledby="<?php echo $labelledby; ?>">
              <?php }else{ ?>
                <div class="tab-pane fade show" id="<?php echo $id; ?>" role="tabpanel" aria-labelledby="<?php echo $labelledby; ?>">
              <?php } ?>
             <?php $slider_id = 'demo_w'.$key; 
                   $slider_target = '#demo_w'.$key; ?>
              <div id="<?php echo $slider_id; ?>" class="carousel slide web-slide" data-tabname="<?php echo $value['tab_name']; ?>" data-ride="carousel">
                <ul class="carousel-indicators">
                  <?php 
                    $slider_content = json_decode($value['slider_content'],1);
                    foreach ($slider_content as $k => $val) {
                      if($k == 0){ ?>
                        <li data-target="<?php echo $slider_target; ?>" data-tabname="<?php echo $value['tab_name']; ?>" data-slide-to="<?php echo $k; ?>" class="active select-slider column2-indicator"></li>
                      <?php }else{ ?>
                        <li data-target="<?php echo $slider_target; ?>" data-tabname="<?php echo $value['tab_name']; ?>" data-slide-to="<?php echo $k; ?>" class="select-slider column2-indicator"></li>
                      <?php } } ?>
                </ul>
                <div class="carousel-inner slider_1"> <?php 
                    $slider_content = json_decode($value['slider_content'],1);
                    foreach ($slider_content as $k => $val) {
                      if($k == 0){ ?>
                        <div class="carousel-item active">
                          <img src="https://via.placeholder.com/468x312/6abbd8/808080?text=+" alt="Chicago" style="width:100%">
                          <div class="carousel-caption">
                            <p><?php echo $val; ?></p>
                          </div>   
                        </div>
                      <?php }else{ ?>
                       <div class="carousel-item">
                          <img src="https://via.placeholder.com/468x312/6abbd8/808080?text=+" alt="Chicago" style="width:100%">
                          <div class="carousel-caption">
                            <p><?php echo $val; ?></p>
                          </div>   
                        </div>
                  <?php } } ?>
                </div>
              </div>
            </div>
            <?php 
              if($key == $count-1){ ?>
                </div>
              </div>
              <?php foreach ($data as $slide_key => $slide_value) { 
                $slider_img = json_decode($slide_value['slider_image'],1);
                if($slide_key == 0){ ?>
                  <div class="col-sm-6 back slide-imgs" id="<?php echo $slide_value['tab_name']; ?>">
                <?php }else{ ?>
                   <div class="col-sm-6 back slide-imgs" id="<?php echo $slide_value['tab_name']; ?>" style="display:none;">
                <?php } 
                foreach ($slider_img as $slide_key1 => $slide_value1) {
                $id1 = $slide_value['tab_name'].$slide_key1;  
                  if($slide_key1 == 0){ ?>
                    <img id="<?php echo $id1; ?>" src="<?php echo slider_access_path.$slide_value1; ?>" alt="New York" style="width:100%" class="column3-image">
                  <?php }else{ ?>
                    <img id="<?php echo $id1; ?>" src="<?php echo slider_access_path.$slide_value1; ?>" alt="New York" style="width:100%;display:none;" class="column3-image">
                  <?php } ?>
                  
               <?php } ?>
             </div>
              <?php } ?>
          </div>
              <?php }
             } ?>
 </div>
</div>
</div>
</div>
</div>

<main class="media-block">
  <div class="accordion">
    <?php 
            $count = count($data);
            foreach ($data as $key => $value) { 
              ?>
    <?php if($key == 0){ ?>
      <div class="accordion-item active">
    <?php }else{ ?>
      <div class="accordion-item">
    <?php } ?>
    
      <div class="accordion-header">
        <h2><img src="<?php echo icon_access_path.$value['tab_icon']; ?>" style="width: 40px;">&nbsp;&nbsp;&nbsp; <?php echo $value['tab_name']; ?></h2>
      </div>
      <div class="accordion-body">
        <div class="row mt-2">
          <?php $slider_id = 'demo_m'.$key; 
                $slider_target = '#demo_m'.$key; ?>
          <div id="<?php echo $slider_id; ?>" class="carousel slide" data-ride="carousel">
                <ul class="carousel-indicators">
                  <?php 
                    $slider_content = json_decode($value['slider_content'],1);
                    foreach ($slider_content as $k => $val) {
                      if($k == 0){ ?>
                        <li data-target="<?php echo $slider_target; ?>" data-tabname="<?php echo $value['tab_name']; ?>" data-slide-to="<?php echo $k; ?>" class="active select-slider column2-indicator"></li>
                      <?php }else{ ?>
                        <li data-target="<?php echo $slider_target; ?>" data-tabname="<?php echo $value['tab_name']; ?>" data-slide-to="<?php echo $k; ?>" class="select-slider column2-indicator"></li>
                      <?php } } ?>
                </ul>
                <div class="carousel-inner slider_1"> <?php 
                    $slider_content = json_decode($value['slider_content'],1);
                    foreach ($slider_content as $k => $val) {
                      if($k == 0){ ?>
                        <div class="carousel-item active">
                          <img src="https://via.placeholder.com/468x312/6abbd8/808080?text=+" alt="Chicago" style="width:100%">
                          <div class="carousel-caption">
                            <p><?php echo $val; ?></p>
                          </div>   
                        </div>
                      <?php }else{ ?>
                       <div class="carousel-item">
                          <img src="https://via.placeholder.com/468x312/6abbd8/808080?text=+" alt="Chicago" style="width:100%">
                          <div class="carousel-caption">
                            <p><?php echo $val; ?></p>
                          </div>   
                        </div>
                  <?php } } ?>
                </div>
              </div>
        </div>
      </div>
    </div>
  <?php } ?>
  </div>
  
</main>




<?php include "footer.php"; ?>

<style type="text/css">
.media-block{
  display: none;
}
.back{
  background-color: #ccc;
  padding: 0;
}
.carousel-indicators li{
  width: 10px;
  height: 10px;
  border-radius: 50px!important;
  border: none;
}
.nav-pills .nav-link.active, .nav-pills .show > .nav-link {
    color: #000;
    background-color: #fff;
    border: 1px solid #ccc;
    box-shadow: 3px 3px 5px #ccc;
    font-size: 0.9em;
    border-radius: 0!important;
}
.nav-pills .nav-link{
  font-size: 0.9em;
  color: #000;
  background-color: #fff;
  margin-bottom: 10px!important;
}
body{
  background-color: #143577;
}
.nav-link {
    display: block;
    padding: 1rem 1rem;
}
</style>

<script type="text/javascript">
  $(document).ready(function(){
     $('.column2-indicator').on('click',function(){
      var slide_cnt;
      var total_slide_cnt;
      var tabname = $(this).attr('data-tabname');
      $('.column3-image').hide();
      slide_cnt = $(this).attr('data-slide-to');
      var id = tabname+slide_cnt;
      $('#'+id).removeAttr("style");
      $('#'+id).css("width","100%");
    });

     $('.tab-names').on('click',function(){
      var tabname = $(this).attr('data-tabname');
      var id = tabname+'0';
      $('.slide-imgs').hide();
      $('#'+tabname).show();
      $('#'+id).removeAttr("style");
      $('#'+id).css("width","100%");  
     });

     var liCount = 0;

    // $('.web-slide').bind('slid.bs.carousel', function (e) {
    //   var slide_cnt;
    //   var total_slide_cnt;
    //   var libImageCount = $(this).children().children("li").length;
    //   if(liCount == libImageCount){
    //       liCount = 0;
    //   }  
    //   $.each($(this).children().children("li"), function(){
    //     slide_cnt = $(this).attr('data-slide-to');
    //     if(liCount == slide_cnt){  
    //       $('.column3-image').hide();
    //       var tabname = $(this).attr('data-tabname');
    //       var id = tabname+slide_cnt;
    //       $('#'+id).removeAttr("style");
    //       $('#'+id).css("width","100%");
    //     }              
    //   });
    //   liCount ++;
    //   // var tabname = $(this).children().attr('class');
    //   // slide_cnt =  $(this).children().attr('class');
    //   // alert("tabname " + tabname);
    //   // alert("slide_cnt " + slide_cnt);
    //   // $('.column3-image').hide();

      
    // });

    
  });

</script>
<style type="text/css">
@media only screen and (max-width: 416px) {
  .media-hide {
      display: none!important;
  }
  .media-block {
        display: block!important;
    }
  .m-fs-9{
    font-size: 1.2rem!important;
  }
  .m-fs-7{
    font-size: 0.7rem!important;
  }
  .m-mb-0{
    margin-bottom: 0!important;
  }
}

.fs-12{
    font-size: 2rem;
  }
.fs{
  font-size: 1rem;
}
main {
  padding: 30px 10px;
}

.accordion {
  max-width: 550px;
}
.accordion-item {
  background-color: transparent;
  /*margin-bottom: 15px;*/
  border-radius: 5px;
  box-shadow: 0 2px 9px 0 rgba(0, 0, 0, 0.1);
  transition: background-color 0.2s ease-in 0.3s;
}
.accordion-item.active {
  /*background-color: white;*/
  transition: background-color 0.2s ease-in 0s;
}
.accordion-item.active .accordion-header {
  color: black;
  background-color: white;
  transition: background-color 0.2s ease-in 0s, color 0.2s ease-in 0.2s;
}
.accordion-item.active .accordion-header h2:before, .accordion-item.active .accordion-header h2:after {
  background-color: black;
  transition: background-color 0.2s ease-in 0.2s, -webkit-transform 0.2s ease 0.1s;
  transition: background-color 0.2s ease-in 0.2s, transform 0.2s ease 0.1s;
  transition: background-color 0.2s ease-in 0.2s, transform 0.2s ease 0.1s, -webkit-transform 0.2s ease 0.1s;
}
.accordion-item.active .accordion-header h2:before {
  display: none;
}
.accordion-item.active .accordion-header h2:after {
  -webkit-transform: rotate(90deg);
          transform: rotate(90deg);
}
.accordion-item.active .accordion-body {
  max-height: 900px;
  /*padding: 0 15px 15px;*/
  transition: max-height 0.3s ease-in 0s, padding 0.2s ease-in 0s;
}
.accordion-item.active .accordion-body p {
  opacity: 1;
  transition: opacity 0.2s ease-in 0.2s;
}
.accordion-header {
  color: #000;
  background-color: #fff;
  /*border-radius: 5px;*/
  padding: 15px 15px;
  cursor: pointer;
  transition: background-color 0.2s ease-out 0.3s, color 0.2s ease-out 0s;
}
.accordion-header h2 {
  position: relative;
  font-size: 1rem;
  font-weight: 500;
  letter-spacing: 0.025em;
  margin: 0;
}
.accordion-header h2:before, .accordion-header h2:after {
  content: "";
  position: absolute;
  background-color: #000;
  transition: background-color 0.2s ease-in 0s, -webkit-transform 0.2s ease 0s;
  transition: background-color 0.2s ease-in 0s, transform 0.2s ease 0s;
  transition: background-color 0.2s ease-in 0s, transform 0.2s ease 0s, -webkit-transform 0.2s ease 0s;
}
.accordion-header h2:before {
  width: 10px;
  height: 2px;
  right: 0;
  top: calc(50% - 1px);
}
.accordion-header h2:after {
  width: 2px;
  height: 10px;
  right: 4px;
  top: calc(50% - 5px);
  -webkit-transform: none;
          transform: none;
}
.accordion-body {
  max-height: 0;
  padding: 0 15px;
  overflow: hidden;
  transition: max-height 0.2s ease-out 0s, padding 0.1s ease-out 0.2s;
  margin-bottom: 10px;
  /*background-color: #fff;*/
}

.credits {
  position: absolute;
  bottom: 30px;
  right: 30px;
  font-size: 14px;
}

</style>
<script type="text/javascript">
const accordionItem = document.querySelectorAll('.accordion-item');
                             
const onClickAccordionHeader = e => {
  if (e.currentTarget.parentNode.classList.contains('active')) {
    e.currentTarget.parentNode.classList.remove("active");
  } else {
    Array.prototype.forEach.call(accordionItem, (e) => {
      e.classList.remove('active');
    });
    e.currentTarget.parentNode.classList.add("active");
  }
};

const init = () => {
  Array.prototype.forEach.call(accordionItem, (e) => {
    e.querySelector('.accordion-header').addEventListener('click', onClickAccordionHeader, false);
  });
};

document.addEventListener('DOMContentLoaded', init);
</script>