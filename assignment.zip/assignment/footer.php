<script src="JS/jquery.min.js"></script>
<script src="JS/bootstrap.min.js"></script>
<script src="JS/fontawesome.min.js"></script>
<script src="JS/popper.min.js"></script>
</body>
</html>
