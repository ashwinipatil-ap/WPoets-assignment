<?php
	function fetch_data_by_id($id){
		include "../database_connection.php";
		$query  = 'SELECT * FROM tbl_manage_tab_content WHERE id="'.$id.'"';
		$retval = mysqli_query($conn, $query) or die(mysqli_error());
		$result = mysqli_fetch_assoc($retval);
		return $result;
	}
	function fetch_data(){
		include "../database_connection.php";
		$query  = 'SELECT * FROM tbl_manage_tab_content';
		$retval = mysqli_query($conn, $query) or die(mysqli_error());
		$result = '';
		while ($row = mysqli_fetch_assoc($retval)) {
		    $result[] = $row;
		}
		return isset($result)?$result:'';
	}

	function get_data(){
		include "database_connection.php";
		$query  = 'SELECT * FROM tbl_manage_tab_content WHERE status = 1';
		$retval = mysqli_query($conn, $query) or die(mysqli_error());
		$result = '';
		while ($row = mysqli_fetch_assoc($retval)) {
		    $result[] = $row;
		}
		return isset($result)?$result:'';
	}
?>