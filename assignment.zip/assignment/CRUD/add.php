<?php
   include "../header.php";
   include "../access_data.php";
?>
<div class="container mt-5 mb-2">
	<div class="row">
		<div class="col-sm-10">
			<h4 class="font-weight-bold">Add Details</h4>
		</div>
		<div class="col-sm-2">
			<button type="button" onclick="javascript:window.history.back(-1);" class="btn btn-danger form-control"><i class="fa fa-arrow-left"></i>&nbsp;Back</button>
		</div>
	</div>
</div>
<div class="container shadow p-3">
	<form name="create_data" method="post" id="create_data" action="access_data.php" enctype="multipart/form-data">
	<div class="row">
		<div class="col-sm-6">
			<div class="row">
	            <div class="col-sm-2">
	               <lable>Tab Icon:</lable>
	            </div>
	            <div class="col-sm-8">
	               <input name="tab-icon" type='file' data-img="blah" onchange="readURL(this,'blah');" required/>
	            </div>
	            <div class="col-sm-2">
	               <img id="blah" class="d-none" src="#" alt=""/>
	            </div>
	         </div>
		</div>
		<div class="col-sm-6">
			<div class="row">
	            <div class="col-sm-2">
	               <lable>Tab Name:</lable>
	            </div>
	            <div class="col-sm-10">
	               <input class="form-control" type="text" name="tab_name" value="" placeholder="Tab Name" required/>
	            </div>
	         </div>
		</div>
	</div>
	<hr>
	<div class="row add-contents">
		<div class="col-sm-5">
			<div class="row content-col">
	            <div class="col-sm-3">
	               <lable>Column 2 Slider 1 Content:</lable>
	            </div>
	            <div class="col-sm-7">
	               <textarea class="form-control" rows="4" cols="50" name="slider_content[]" required>
	               </textarea>
	            </div>
	            <div class="col-sm-1">
	               <button type="button" class="btn btn-danger add-btn"><i class="fa fa-plus"></i></button> 
	            </div>
	         </div>
		</div>
		<div class="col-sm-2"></div>
		<div class="col-sm-5">
			<div class="row slider_img">
	            <div class="col-sm-4">
	               <lable>Column 3 Slider 1 Image:</lable>
	            </div>
	            <div class="col-sm-6">
	               <input name="slider_image[]" type='file' multiple onchange="readURL(this,'sld_1');" required/>
	            </div>
	            <div class="col-sm-2">
	               <img id="sld_1" class="d-none" src="#" alt=""/>
	            </div>
	         </div>
		</div>
	</div>
	<hr>
	<div class="row">
		<div class="col-sm-6">
			<div class="row">
		        <div class="col-sm-4">
		           <lable>Status:</lable>
		        </div>
		        <div class="col-sm-8">
		           <select class="form-control" name="status">
		              <option value="1">Active</option>
		              <option value="0">Inactive</option>
		           </select>
		        </div>
		     </div>
		</div>
		<div class="offset-2 col-sm-2">
			<button type="submit" class="btn btn-danger form-control"><i class="fa fa-save"></i>&nbsp;Save Details</button>
		</div>
		<div class="col-sm-2">
			<button type="reset" class="btn btn-danger form-control"><i class="fa fa-refresh fa-fw"></i>&nbsp;Reset</button>
		</div>
	</div>
  </form>
</div>
<?php
   include "../footer.php";
?>
<style type="text/css">
   .mg-content{
   font-weight: bold;
   font-size: 1.9em;
   font-weight: bold;
   }
   body{
   font-size: 0.9em;
   font-family: Serif;
   }
   .btn-danger:hover {
   color: #fff;
   background-color: #9b030d;
   border-color: #af120a;
   }
</style>
<script type="text/javascript">
   var contentCont = 2;
   var imgCont = 2;
    function readURL(input,id) {
         if (input.files && input.files[0]) {
             var reader = new FileReader();
   
             reader.onload = function (e) {
                 $('#'+id)
                 	.removeClass('d-none')
                     .attr('src', e.target.result)
                     .width(50)
                     .height(70);
             };
   
             reader.readAsDataURL(input.files[0]);
         }
     }
     $(document).ready(function(){
     	//==============Add Contents========================
     	$('.add-btn').on('click',function(){
     		//Content
     		var addContent = '';
     		var sld_id = 'sld_'+imgCont;
     		addContent = '<div class="row ml-1 mt-2"><div class="col-sm-5"><div class="row content-col"> <div class="col-sm-3"> <lable>Column 2 Slider '+contentCont+' Content:</lable> </div><div class="col-sm-7"> <textarea class="form-control" rows="4" cols="50" name="slider_content[]" required> </textarea> </div><div class="col-sm-1"></div></div></div><div class="col-sm-2"></div><div class="col-sm-5"><div class="row slider_img'+imgCont+'"> <div class="col-sm-4"> <lable>Column 3 Slider '+imgCont+' Image:</lable> </div><div class="col-sm-6"> <input name="slider_image[]" type="file" multiple onchange="readURL(this,"sld_1");" required/> </div><div class="col-sm-2"> <img id=sld_'+imgCont+'" class="d-none" src="#" alt=""/> </div></div></div></div>';
     		$('.add-contents').append(addContent);
     		contentCont++;
     		imgCont++;
     	});
     });
</script>