<!DOCTYPE html>
<html>
<head>
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>WPeot Assignment</title>
	<link href="../CSS/bootstrap.min.css" rel="stylesheet">
	<link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
	<link href="../CSS/jquery-ui.min.css" rel="stylesheet">
	
</head>
<body>
	<?php session_start(); 
		define('icon_access_path','tab_icon/');
		define('slider_access_path','slider_images/');
	?>