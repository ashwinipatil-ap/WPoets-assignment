<?php
   $id = $_REQUEST['cid'];
   include "header.php";
   include "../access_data.php";
   $data = fetch_data_by_id($id);
?>
<div class="container mt-5 mb-2">
	<div class="row">
		<div class="col-sm-10">
			<h4 class="font-weight-bold">Edit Details</h4>
		</div>
		<div class="col-sm-2">
			<button type="button" onclick="javascript:window.history.back(-1);" class="btn btn-danger form-control"><i class="fa fa-arrow-left"></i>&nbsp;Back</button>
		</div>
	</div>
</div>
<div class="container shadow p-3">
	<form name="create_data" method="post" id="create_data" action="edit_details.php" enctype="multipart/form-data">
	<div class="row">
		<div class="col-sm-6">
			<div class="row">
	            <div class="col-sm-2">
	               <lable>Tab Icon:</lable>
	            </div>
	            <div class="col-sm-8">
	               <input name="tab-icon" type='file' data-img="blah" onchange="readURL(this,'blah');"/>
	            </div>
	            <div class="col-sm-2">
	               <img id="blah" src="<?php echo icon_access_path.$data['tab_icon'];?>" style="width: 100px; height:40px;">
	            </div>
	         </div>
		</div>
		<div class="col-sm-6">
			<div class="row">
	            <div class="col-sm-2">
	               <lable>Tab Name:</lable>
	            </div>
	            <div class="col-sm-10">
	               <input class="form-control" type="text" name="tab_name" value="<?php echo $data['tab_name']; ?>" required/>
	            </div>
	         </div>
		</div>
	</div>
	<hr>
	<?php 
      $slider_content = json_decode($data['slider_content'],1);
      $slider_image   = json_decode($data['slider_image'],1);
      $count = count($slider_content); ?>
   <input type="hidden" id="count" value="<?php echo $count+1; ?>">
   <input type="hidden" name="id" value="<?php echo $data['id']; ?>">
   <?php foreach ($slider_content as $key => $value) { 
      $sel_id = 'sld_'.$key+1;
      if($key == $count-1){ ?>
   		<div class="row add-contents mt-2">
      <?php }else{ ?>
        <div class="row mt-2">
         <?php } ?>

         <div class="col-sm-5">
			<div class="row content-col">
	            <div class="col-sm-3">
	               <lable>Column 2 Slider <?php echo $key+1; ?> Content:</lable>
	            </div>
	            <div class="col-sm-7">
	              <textarea class="form-control" rows="4" cols="50" name="slider_content[]" required><?php echo $value; ?></textarea>
	            </div>
	            <div class="col-sm-1">
	            </div>
	         </div>
		</div>
		<div class="col-sm-7">
			<div class="row slider_img">
	            <div class="col-sm-4">
	               <lable>Column 3 Slider <?php echo $key+1; ?> Image:</lable>
	            </div>
	            <div class="col-sm-5">
	               <input name="slider_image[]" type='file' multiple onchange="readURL(this,$sel_id);" />

	            </div>
	            <div class="col-sm-3">
	               <img id="<?php echo $sel_id; ?>" src="<?php echo slider_access_path.$slider_image[$key];?>" style="width: 100px; height:40px;">
	            </div>
	         </div>
		</div>
	</div>
          <?php } ?>
	<hr>
	<div class="row">
		<div class="col-sm-6">
			<div class="row">
		        <div class="col-sm-4">
		           <lable>Status:</lable>
		        </div>
		        <div class="col-sm-8">
		           <select class="form-control" name="status">
		              <?php if($data['status'] == 1){ ?>
                  <option value="1" selected>Active</option>
                  <option value="0">Inactive</option>
                  <?php }else{ ?>
                  <option value="1">Active</option>
                  <option value="0" selected>Inactive</option>
                  <?php } ?>
		           </select>
		        </div>
		     </div>
		</div>
		<div class="offset-2 col-sm-2">
			<button type="submit" class="btn btn-danger form-control"><i class="fa fa-save"></i>&nbsp;Save Details</button>
		</div>
		<div class="col-sm-2">
			<button type="reset" class="btn btn-danger form-control"><i class="fa fa-refresh fa-fw"></i>&nbsp;Reset</button>
		</div>
	</div>
  </form>
</div>
<?php
   include "footer.php";
?>
<link href="../CSS/add.css" rel="stylesheet">
<script src="../JS/edit.js"></script>