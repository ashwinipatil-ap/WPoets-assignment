<?php
session_start();
$valid_formats = array('jpg', 'png', 'gif');
$max_file_size = 1024*5000; //100 kb
$path = 'slider_images/'; // Upload directory for slider Images
$count = 0;
foreach ($_FILES['slider_image']['name'] as $f => $name) {
if ($_FILES['slider_image']['error'][$f] == 4) {
continue; // Skip file if any error found
}
if ($_FILES['slider_image']['error'][$f] == 0) {
if ($_FILES['slider_image']['size'][$f] > $max_file_size) {
$message[] = $name.' is too large!.';
continue; // Skip large files
}
elseif( ! in_array(pathinfo($name, PATHINFO_EXTENSION), $valid_formats) ){
$message[] = $name.' is not a valid format';
continue; // Skip invalid file formats
}
else{ // No error found! Move uploaded files
if(move_uploaded_file($_FILES['slider_image']['tmp_name'][$f], $path.$name))
$count++; // Number of successfully uploaded file
$upload_name[] = $name;
}
}
}
$TabIconpath = 'tab_icon/'; // Upload directory for Tab Images
if(move_uploaded_file($_FILES['tab-icon']['tmp_name'], $TabIconpath.$_FILES['tab-icon']['name'])){
	$tab_icon = $_FILES['tab-icon']['name'];
}
$data['tab_name'] = $_POST['tab_name'];
$data['status']   = $_POST['status'];
$data['tab_name'] = $_POST['tab_name'];
$path = 'tab_icon/';
if(move_uploaded_file($_FILES['tab-icon']['tmp_name'], $path.$_FILES['tab-icon']['name'])){
	$tab_icon = $_FILES['tab-icon']['name'];
}

foreach ($_POST['slider_content'] as $k => $val) {
	$slider_content[] = trim($val);
}
$data['tab_icon'] = $tab_icon;
$data['slider_image'] = json_encode($upload_name);
$data['slider_content'] = json_encode($slider_content);
$data['created_on'] = date('Y-m-d H:i:s');
include "../database_connection.php";
//=================Inserting data====================
$query = "INSERT INTO tbl_manage_tab_content (id,tab_name,tab_icon,slider_content,slider_image,status,created_on) VALUES (NULL,'".$data['tab_name']."','".$data['tab_icon']."','".$data['slider_content']."','".$data['slider_image']."','".$data['status']."','".$data['created_on']."')";
$retval = mysqli_query($conn, $query);
$_SESSION['status_flag'] = 1;
echo "<script>window.open('index.php','_self')</script>";
?>