<?php
include "../header.php";
include "../access_data.php";
$data = fetch_data();
if(isset($_SESSION['status_flag']) && $_SESSION['status_flag'] == 1){ 
echo '<script>alert("Record Added Successfully")</script>';
$_SESSION['status_flag'] = 0; }
if(isset($_SESSION['status_flag']) && $_SESSION['status_flag'] == 2){ 
echo '<script>alert("Record Updated Successfully")</script>';
$_SESSION['status_flag'] = 0; } 
if(isset($_SESSION['status_flag']) && $_SESSION['status_flag'] == 3){ 
echo '<script>alert("Record Deleted Successfully")</script>';
$_SESSION['status_flag'] = 0; } ?>

   	<div class="container">
   		<div class="row mt-4">
		   	<div class="col-sm-10 mg-content">Manage Contents</div>
		   	<div class="col-sm-2"><i class="fa fa-plus"></i>
		   		<a href="add.php" class=""><button class="btn btn-danger form-control">Add</button></a>
		   	</div>
   		</div>

   		<div class="row mt-4">
   			<table class="table table-bordered table-striped table-hover" style="width:100%">
		    <thead>
		      <tr>
		        <th>Sl. No</th>
		        <th>Tab Name</th>
		        <th>Tab Icon</th>
		        <th>Slider Contents/Images</th>
		        <th>Status</th>
		        <th>Created On</th>
		        <th>Updated On</th>
		        <th>Action</th>
		      </tr>
		    </thead>
		    <tbody>
		      <?php 
		      	if(isset($data) && !empty($data)){
		      		$sl_no = 0;
			      	foreach ($data as $key => $value) {
			      		$sl_no++; ?>
			      		<tr>
			      			<td><?php echo $sl_no; ?></td>
			      			<td><?php echo $value['tab_name']; ?></td>
			      			<td><img src="<?php echo icon_access_path.$value['tab_icon'];?>" style="width: 100px; height:40px;"> </td>
			      			<td><table class="table" style="margin-bottom:0;">
                                    <?php 
                                    $tab_content  = json_decode($value['slider_content'],1);
                                    $slider_image = json_decode($value['slider_image'],1);
                                    $index = 0;
                                    foreach ($tab_content as $row){ ?>
                                    <tr>
                                       <td><?php echo $row; ?></td>
                                       <td><img src="<?php echo slider_access_path.$slider_image[$index];?>" style="width: 100px; height:40px;"> </td>
                                    </tr>
                                    <?php 
                                    	$index++;
                                	} ?>    
                                 </table></td>
			      			<td><?php if($value['status'] == 1){
			      				echo "Active";
			      				 }else{ 
			      				echo "Inactive";
			      			} ?></td>
			      			<td><?php echo date('d-m-Y  H:ia',strtotime($value['created_on'])); ?></td>
			      			<td><?php echo isset($value['updated_on'])?date('d-m-Y  H:ia',strtotime($value['updated_on'])):''; ?></td>
			      			<td><?php
                                 echo '<a href="edit.php?cid='.$value["id"].')" title="Edit"><i class="fa fa-edit fa-fw fa-lg" style="color:#aaaaaa;"></i>Edit</a> | ';
                                 echo '<a href="delete_record.php?id='.$value["id"].')" title="Delete"><i class="fa fa-trash fa-fw fa-lg" style="color:#b80303;"></i>Delete</a>';
                                 ?></td>
			      	    </tr>
			    <?php  	}
		        }
		      ?>
		    </tbody>
		  </table>
   		</div>

   	</div>
<?php include "../footer.php"; ?>
 <style type="text/css">
 	.mg-content{
 		font-weight: bold;
 	}
 </style>
 <script type="text/javascript">
 	$(document).ready(function(){
 		// $('.edit').on('click',function(){
 		// 	var id = $(this).attr('data-val');
 		// 	window.open('edit.php?cid='+id,'_self');
 		// });
 	});
 </script>