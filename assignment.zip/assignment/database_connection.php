<?php
	$dbserver = "localhost";
	$dbuser = "root";
	$dbpass = "root";
	$dbname = "test";
	
	$conn = mysqli_connect($dbserver, $dbuser, $dbpass, $dbname);
	
	if(mysqli_connect_errno()) {
		die("Unable to connect to database:" . mysqli_connect_error());
	} else {
		echo "";
	}
?>