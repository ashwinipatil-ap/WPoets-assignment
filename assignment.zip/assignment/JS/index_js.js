 const accordionItem = document.querySelectorAll('.accordion-item');
                                
   const onClickAccordionHeader = e => {
     if (e.currentTarget.parentNode.classList.contains('active')) {
       e.currentTarget.parentNode.classList.remove("active");
     } else {
       Array.prototype.forEach.call(accordionItem, (e) => {
         e.classList.remove('active');
       });
       e.currentTarget.parentNode.classList.add("active");
     }
   };
   
   const init = () => {
     Array.prototype.forEach.call(accordionItem, (e) => {
       e.querySelector('.accordion-header').addEventListener('click', onClickAccordionHeader, false);
     });
   };
   
   document.addEventListener('DOMContentLoaded', init);
$(document).ready(function(){
     $("#demo_w0").on('slid.bs.carousel', function () {
       var slide_cnt;
       var total_slide_cnt;
       var slino;
       var tabname = $(this).attr('data-tabname');
       $('.demo_w0').each(function () {
         var classname = $(this).attr('class');
         n = classname.indexOf("active");
         if(n != -1){
           slino = $(this).attr('data-slide-to');
           $('.column3-image').hide();
            var id = '#'+tabname+slino;
           $(id).show();
         }
       });
     });
     $("#demo_w1").on('slid.bs.carousel', function () {
       var slide_cnt;
       var total_slide_cnt;
       var slino;
       var tabname = $(this).attr('data-tabname');
       $('.demo_w1').each(function () {
         var classname = $(this).attr('class');
         n = classname.indexOf("active");
         if(n != -1){
           slino = $(this).attr('data-slide-to');
           $('.column3-image').hide();
            var id = '#'+tabname+slino;
           $(id).show();
         }
   
       });
     });
     $("#demo_w2").on('slid.bs.carousel', function () {
       var slide_cnt;
       var total_slide_cnt;
       var slino;
       var tabname = $(this).attr('data-tabname');
       $('.demo_w2').each(function () {
         var classname = $(this).attr('class');
         n = classname.indexOf("active");
         if(n != -1){
           slino = $(this).attr('data-slide-to');
           $('.column3-image').hide();
            var id = '#'+tabname+slino;
           $(id).show();
         }
   
       });
     });
      $('.tab-names').on('click',function(){
       var tabname = $(this).attr('data-tabname');
       var id = tabname+'0';
       $('.slide-imgs').hide();
       $('#'+tabname).show();
       $('.column3-image').hide();
       var id1 = '#'+tabname+0;
       $(id1).show();
       $('#'+id).removeAttr("style");
       $('#'+id).css("width","100%");  
      });
      var liCount = 0;
   });