var contentCont = $('#count').val();
   var imgCont = $('#count').val();
    function readURL(input,id) {
         if (input.files && input.files[0]) {
             var reader = new FileReader();
   
             reader.onload = function (e) {
                 $('#'+id)
                  .removeClass('d-none')
                     .attr('src', e.target.result)
                     .width(50)
                     .height(70);
             };
             reader.readAsDataURL(input.files[0]);
         }
     }