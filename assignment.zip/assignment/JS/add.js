 var contentCont = 2;
   var imgCont = 2;
    function readURL(input,id) {
         if (input.files && input.files[0]) {
             var reader = new FileReader();
   
             reader.onload = function (e) {
                 $('#'+id)
                  .removeClass('d-none')
                     .attr('src', e.target.result)
                     .width(50)
                     .height(70);
             };
   
             reader.readAsDataURL(input.files[0]);
         }
     }
     $(document).ready(function(){
      //==============Add Contents========================
      $('.add-btn').on('click',function(){
        //Content
        var addContent = '';
        var sld_id = 'sld_'+imgCont;
        addContent = '<div class="row ml-1 mt-2"><div class="col-sm-5"><div class="row content-col"> <div class="col-sm-3"> <lable>Column 2 Slider '+contentCont+' Content:</lable> </div><div class="col-sm-7"> <textarea class="form-control" rows="4" cols="50" name="slider_content[]" required> </textarea> </div><div class="col-sm-1"></div></div></div><div class="col-sm-2"></div><div class="col-sm-5"><div class="row slider_img'+imgCont+'"> <div class="col-sm-4"> <lable>Column 3 Slider '+imgCont+' Image:</lable> </div><div class="col-sm-6"> <input name="slider_image[]" type="file" multiple onchange="readURL(this,"sld_1");" required/> </div><div class="col-sm-2"> <img id=sld_'+imgCont+'" class="d-none" src="#" alt=""/> </div></div></div></div>';
        $('.add-contents').append(addContent);
        contentCont++;
        imgCont++;
      });
     });