-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: May 30, 2019 at 04:27 AM
-- Server version: 5.7.19
-- PHP Version: 5.6.31

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `test`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_manage_tab_content`
--

DROP TABLE IF EXISTS `tbl_manage_tab_content`;
CREATE TABLE IF NOT EXISTS `tbl_manage_tab_content` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tab_name` varchar(250) DEFAULT NULL,
  `tab_icon` text,
  `slider_content` text,
  `slider_image` text,
  `status` int(11) DEFAULT NULL COMMENT '0-Inactive 1-Active',
  `created_on` datetime DEFAULT NULL,
  `updated_on` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_manage_tab_content`
--

INSERT INTO `tbl_manage_tab_content` (`id`, `tab_name`, `tab_icon`, `slider_content`, `slider_image`, `status`, `created_on`, `updated_on`) VALUES
(6, 'Learning', 'DL-learning.svg', '[\"Learning is the process of acquiring new, or modifying existing, knowledge, behaviors, skills, values, or preferences.\",\"Humans learn before birth and continue until death as a consequence of ongoing interactions between people and their environment.\",\"Learning may occur as a result of habituation, or classical conditioning seen only in relatively intelligent animals.\"]', '[\"DL-Learning-1.jpg\",\"DL-Technology.jpg\",\"DL-Communication.jpg\"]', 1, '2019-05-25 05:50:02', '2019-05-29 12:27:31'),
(7, 'Technology', 'DL-technology.svg', '[\"Technology is the collection of techniques, skills, methods, and processes used in the production of goods or services.\",\"The simplest form of technology is the development and use of basic tools. The prehistoric discovery of how to control fire and the later Neolithic.\"]', '[\"DL-Technology.jpg\",\"DL-Learning-1.jpg\"]', 1, '2019-05-25 05:52:19', '2019-05-29 12:28:15'),
(8, 'Communication', 'DL-communication.svg', '[\"Communication is the act of conveying meanings from one entity or group to another through the use signs, symbols, and semiotic rules.\"]', '[\"DL-Communication.jpg\"]', 1, '2019-05-25 05:53:26', '2019-05-29 12:28:35');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
